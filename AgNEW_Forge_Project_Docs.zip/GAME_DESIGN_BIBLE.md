# Mirrored Dungeon — Game Design Bible

**Studio:** AgNEW Forge (preferred working identity)  
**Last curated:** 2026-10-25  
**Owner:** Project creator; Codex implements approved designs  
**Document status:** Creative/design source of truth; it is **not** proof that features exist in the repository.

> **How to use this file:** The **Current Design Decisions** below incorporate the most recent discussions. The original detailed campaign proposal, *The Broken Vigil* (25 October 2026), is preserved unabridged in Appendix A as source material. If two sections conflict, the newest explicit decision takes precedence; flag unresolved conflicts rather than inventing changes. Technical completion is tracked in `CHANGELOG.md`, never inferred from this design file.

## 1. Game identity and design pillars

**Mirrored Dungeon** is a mobile-first dark fantasy action RPG from **AgNEW Forge**. Its foundation is skill-based combat, meaningful decisions, clearly signaled threats, and systems that are simple to read but deep to master.

- **Choices have consequences.** A faster route competes with a tempting but costly reward; decisions aren't merely cosmetic.
- **Player agency over hidden corrections.** No undisclosed rubber-banding, automatic catch-up bonuses, or forced outcomes.
- **Fair competition.** Mirrored competitive runs start from equivalent seeded layouts, enemy arrangements, and reward opportunities. Asymmetry comes from player decisions and boss inheritance.
- **Readable combat.** Clear telegraphs, line of sight, legitimate cover, understandable collision, predictable buff drawbacks, and useful feedback on iPhone screens.
- **Dense worlds over empty sprawl.** Campaign exploration is physically navigable and connected, with authored landmarks and purposeful encounters; not a text-driven mission-deployment list.
- **No pay-to-win.** Paid features must not increase combat power or competitive information access.

## 2. Game modes and separation

### Competitive Arena / mirrored race (the original prototype)

- Two players race through distinct but equivalent mirrored dungeons, approximately **10–15 minutes** per run.
- Each player chooses boss order. Defeating a boss modifies surviving bosses in their own run and strengthens the corresponding boss in the opponent's dungeon.
- Ordinary enemy kills can cause bounded opponent reinforcement waves with visible arrival countdowns. Preserve fairness and warning time.
- Add gauntlet paths before themed bosses, controlled random block/hazard placement, and a compact **opponent minimap** showing approximate rival room progress and boss states, not necessarily precise coordinates.
- A small emote wheel lets the opponent see short non-blocking magical projections/emotes. Support mute and rate limits. Emotes are cosmetic.
- Arena balance, matching conditions, timers, and saves are **separate** from Campaign progression. Persistent campaign loot must not distort a fair arena race.

### Campaign — the living world

- Persistent characters, story, equipment, side quests, and exploration. No rival race countdown.
- All three classes are playable in all three story parts. The featured class supplies a homeland and personal plot but never locks another class out.
- Replace text-based mission deployment with **walkable Camp → connected roads/wilderness → villages and quest locations → dungeons/strongholds → boss rooms**. Use short area transitions if required for browser performance.
- Regions retain a stable, authored geographic layout, with optional exploration, shortcuts, discovery, local consequences and controlled encounter variation. They do not rearrange randomly on every visit.
- Design for solo play and eventual online two-player co-op on separate devices. Four-player support is a later performance-gated option, **not an implemented claim**.

### Endless Descent and other future modes

- Separate optional persistent dungeon progression: voluntary Camp returns, a protected physical chest/stash, farming unlocked floors/checkpoints, salvage/crafting and a streamlined merchant interaction.
- A level-60 cap followed by optional post-cap systems has been discussed for this mode; details and cross-mode progression remain unfinalized.
- A PvP 'vault race' for campaign gear rewards has been suggested, **not approved for the first release**; preserve campaign economy fairness before designing cross-mode rewards.
- Do not allow these future concepts to delay completing the first authored Campaign chapter or reliable Arena races.

## 3. Three-part campaign narrative (working titles)

| Part | Featured homeland | Story destination |
| --- | --- | --- |
| **I — The Broken Oath** | Knight's ruined kingdom | Liberate occupied territories; Warlord → Pyromancer → Necromancer → first form of the Old God possessing the Necromancer. Kingdom saved, Old God escapes. |
| **II — The Veiled Flame** | Mage's homeland | Discover study, imprisonment, and magical failures tied to the Old God and the Mage's past. |
| **III — The Unseen Crown** | Rogue's homeland | Uncover hidden orders and remaining servants; confront the Old God decisively. |

All three working titles may change. **Every part has its own satisfying ending.** Part I's ending is a win with lasting consequences, not a forced defeat or an advertisement for Part II.

**Knight's thematic question:** *“I swore to defend this kingdom. What happens when its rulers are the threat?”* In villages and quests, protecting ordinary people, handling former comrades, and deciding what to rebuild put the oath into practice.

**Part I regions:**

1. **Iron March** — occupied roads, villages, former Knight order, fortifications. Final approach: **Warlord's Armory/Barracks**, boss chamber: **Throne Room**.
2. **Cinder Below** — kingdom mines, furnaces, soul-vessel production. Final approach: **Pyromancer's Lava Cave**, boss chamber: **Fire Sanctuary**.
3. **Hollow Parish** — burial grounds, ancestral dead, funerary culture. Final approach: **Halls of the Dead**, boss chamber: **Necromancer's Crypt**.

The Warlord supplies prisoners to the Pyromancer's forges; the Pyromancer produces vessels for the Necromancer; the Necromancer tries to control the Old God and becomes its host. The Old God's first incarnation is defeated in an actual playable climax.

### Part I pacing and levels

- Level cap **60**. Main storyline targeted for completion around **level 45** in normal play. Levels **46–60** are optional content, not mandatory grinding before the finale.
- The prologue and first chapter cover approximately levels 1–18; Cinder Below 18–32; Hollow Parish 32–43; finale 43–45. These are proposed balance bands, not validated metrics.
- Sessions should allow 15–30-minute chunks with checkpoints, shorter optional encounters, and durable progression.
- Early regions stay explorable after bosses fall. World changes should be physical and visible (freed towns, opened roads, altered NPCs, safe passages), not just journal text.

## 4. First playable world slice: Vigil Camp → Bannerfall → Warlord

**Current next development priority:** Convert the campaign's existing mission menu into a small but explorable world before authoring enormous regions.

- **Vigil Camp:** consecrated fire and wordless chant, physical shared stash/chest, limited useful NPCs, equipment management, safe recovery, travel connections. Keep it cozy/minimal rather than an MMO hub. Rescued NPCs and milestones visibly improve it.
- **Broken Road / approach:** authored paths, cover and introductory encounters, shortcuts and small discoveries; player chooses where to walk.
- **Bannerfall Village:** a damaged, walkable town with ordinary residents, interactive merchants and quests. Initial complete side quests include **The Smith's Son** and **Bread Before Blades**. Rebuilding changes shops, NPCs, safety and appearance.
- **Warlord's fortress:** physical entrance from the world, Armory gauntlet, Throne Room fight, valid return path and durable quest/boss flags.
- Convert existing text mission entries into discoverable world interactions and journal objectives; **preserve existing quest logic, item grants and saves**.

All three character classes must be able to do every required quest and interaction solo. Co-op must not require two simultaneous players to solve essential puzzles.

## 5. Boss gauntlets: risk vs. reward

Each boss has a brief, themed approach teaching combat concepts used by the boss. **Two viable routes:**

- **Direct:** reach the boss as fast as possible without a newly earned gauntlet buff.
- **Optional reward route:** spend roughly 8–15 seconds more (initial target; tune in playtesting), face extra hazard/enemy risk, and earn a **substantial** buff. The direct route itself might take roughly 10–25 seconds for skilled players; these are estimates, not acceptance guarantees.

**Critical commitment rule:** Show the specific buff's **name, exact numerical effect, drawback, and duration BEFORE** the player commits to the detour. No blind mystery rewards. Up to three equal-seeded offers may be shown and one claimed, if the layout supports it. No retroactive auto-buff for falling behind. Selection does not stop a competitive match clock.

**Initial tunable buff designs (proposals, not final balance):**

| Buff | Reward | Drawback / cost |
| --- | --- | --- |
| Berserker's Edge | +30% damage for first 15 seconds of boss encounter | +20% incoming damage during effect; plus detour time |
| Guardian's Pact | 50% reduction to next major boss hit | -15% movement speed for 15 seconds; plus detour time |
| Arcane Surge | 30% faster ability cooldowns for 15 seconds | +15% incoming damage while active; plus detour time |
| Blood Restoration | Immediately restores 30% max HP, capped at full | -15% attack speed for 15 seconds; plus detour time |

The above *trade-off versions* supersede earlier buff-only proposals; keep numbers configurable. Some lighter rewards may cost only the detour, but the strongest ones should impose real risk. Effects cannot accidentally stack, be farmed repeatedly, or carry to unrelated encounters. Boss-timed buffs start on encounter entry; immediate healing triggers on collection.

**Theme:** Warlord teaches cover, shield/charge pressure and chokepoints; Pyromancer teaches lava/vent timing and safe lanes; Necromancer teaches summoned enemy management, priority targeting and cursed tiles.

## 6. Environmental art and gameplay

- Visual style: cohesive **16-bit-inspired pixel art with moderately higher-detail backgrounds**; crisp edges, disciplined palette, consistent camera projection/scale and legible silhouettes at phone size. Art is authored as concept/reference images where appropriate; do not treat flattened pictures as collision maps.
- **Warlord:** weapon racks, crates, banners, barricades and grates in Armory; raised throne, banners, braziers and readable arena in Throne Room.
- **Pyromancer:** basalt/lava pools/fissures, vents and bridgework in Lava Cave; circles, altars, braziers and molten channels in Sanctuary.
- **Necromancer:** grave niches, bones, mausoleum halls, cursed symbols in Halls of the Dead; ritual anchors, sarcophagus, eerie light in Crypt.
- Separate walkable floor, blocking collision, interactive props, decorations, hazards and overlay layers. Validate paths, spawns and objective access. Ensure solid cover blocks appropriate projectiles.
- Controlled seeded obstacles (pillars, rubble, destructible cover) and hazards (fire vents, spikes, cursed slowing runes) diversify layouts; visual warning before damage is mandatory.
- Sprite-sheet frame bleeding was previously reported as a visual issue; prioritize combat and navigation correctness before extended animation polishing.

## 7. Campaign characters, equipment and economy

- Three playable classes: Knight (durability/guard), Mage (ranged/spell control), Rogue (mobility/precision/traps). They are asymmetric but each must complete content solo; situational strengths are welcome, consistent dominance is not.
- Campaign: **five slots** (weapon, armor, boots, charm, relic), item comparison, protected favorites, equipment/skill upgrades and visible effects. Avoid tiny affix clutter.
- Talents: three suggested branches per class. One point at even levels through 60 and class-specific nodes/capstones are **proposed** in the detailed campaign reference. Preserve implemented talents when upgrading schema.
- Crafting: gold, salvage and a small number of territory materials; buy/sell/buyback and fair restoration of exact item instances. Keep vending and crafting streamlined.
- Physical Camp chest as safe stash, merchants/services consolidated in a few natural interactions. Character progression and quest outcomes persist through death/reload.
- Dialogue should explain why NPCs need help; quests should produce discoverable activities in the world, not mandatory text deployment or repeated generic kill counts.

## 8. Co-op, saving and release rules

- Campaign co-op direction: **two devices in one shared world**, private invites first; 4-player only after performance tests. Online networking is not independently verified as shipped.
- Personal characters, loot, XP and quest-reward ledgers; host world state and story decisions; no duplicated items or XP from reconnects, repeated claims or save reloads.
- A server-authoritative service is expected for genuine online co-op; distinguish prototype simulated rival and local co-op from real two-device sessions.
- Maintain separate save domains for **character**, **campaign/world**, and **transient session**. Make migrations/versioning explicit.
- Maintain iPhone-first controls and avoid UI that obscures enemies/hazards. Benchmark performance on actual hardware; do not claim device testing if only browser emulation was run.
- Campaign should not inherit Arena's timed-race economy/skills/balance by accident.

## 9. Monetization and studio presentation (future release work)

- Free game supported by ads **between runs or in menus only**, never during active combat.
- **$4.99 one-time permanent ad removal**; purchases require secure verification and restore logic when monetization is actually enabled.
- Optional **character skins, dungeon/map visual skins, emotes**, and gameplay-earned cosmetics. All cosmetics leave collision, hazards, hitboxes, power, and competitive information equivalent.
- Opponent-visible emotes should be brief, legible, rate-limited and **able to be muted by the recipient**; cannot obscure gameplay.
- **AgNEW Forge** is the favored working studio brand; possible slogan: **“Forging New Ways to Play.”** Verify naming rights before public release.
- Do not let ad/payments infrastructure delay a playable and enjoyable core loop.

## 10. Pending decisions (do not silently invent)

- Exact Campaign overworld size, streaming/transitions, map orientation, and fast-travel unlock rules.
- Which optional Endless Descent systems ship in the first public release and how post-cap equipment connects to Campaign.
- Exact buff values, drawbacks and frequency after telemetry and class testing.
- Final titles, lore details, voice/text scope, total campaign playtime and final room scale.
- Whether existing repository actually contains a real co-op server, physical world navigation, and all proposed quest content (must be inspected).
- Payment provider/hosting/deployment decisions and account design.

## Appendix A — Detailed authored campaign reference (preserved)

The following campaign proposal was supplied on 2026-10-25. It is detailed design/reference material, **not an implementation report**. Newer explicit choices in sections 1–10 above take precedence where scope or world-navigation approach has evolved.

---

# Mirrored Dungeon: The Broken Vigil

Campaign design proposal · 25 October 2026

Status: authored design, not implemented campaign functionality. Names, numbers, and rewards below are initial tuning proposals. Online co-op on separate devices is confirmed. First playable target: one or two players; four-player support is a later milestone, subject to performance testing.

## The campaign promise

A dark-fantasy action RPG about reclaiming a kingdom whose roads, graves, and furnaces feed a broken mirror beneath its capital. The Warlord serves the Pyromancer, who serves the Necromancer, who serves an Old God. Each believes the bargain serves their own ambition. Each is the final boss of a distinct territory, with lesser enemies, greater enemies, elites, named quest bosses, and a developing local story.

The heroes begin at the Vigil Camp, a refuge around a consecrated fire. Its wordless chant is a recurring sound of safety. Rescued people, completed quests, and defeated bosses visibly change the camp. Victories offer relief without removing the world's unease.

The central question: **Who is worth saving when keeping them alive makes the next battle harder?** Choices change encounters, allies, and rewards; they do not silently invalidate another player's character.

Campaign combat keeps movement, jumping, class skills, line of sight, breakable cover, and readable enemy tells. Campaign removes the rival race and global countdown. The current game remains available as Gauntlet mode with independent balance and saves.

## Three-part game

Part I takes place in the Knight's homeland: its war-torn settlements, royal forges, and ancestral burial grounds. Iron March, Cinder Below, and Hollow Parish explore different sides of that kingdom. All three classes remain playable in solo and co-op; the Knight provides the central homeland story, not a mandatory player class.

Part II explores the Mage's world and the Old God's imprisonment. Part III explores the Rogue's world and the final confrontation. These later parts are story directions, not current production commitments. Character transfer and level progression across parts remain to be designed; do not assume a forced reset or a raised cap.

## Campaign structure

Part I has a confirmed level cap of 60, with the main story balanced to be completed around level 45 on normal difficulty. Levels 46–60 are optional progression, not a requirement to reach or beat the ending. Campaign length must be re-estimated against this broader progression and the town quest content; the earlier 6–8 hour estimate is superseded. Missions should support 15–30 minute sessions with checkpoints and shorter optional encounters.

| Chapter | Territory | Suggested levels | Main boss | Identity |
|---|---|---:|---|---|
| Prologue | The Last Watch | 1–5 | The Tollkeeper | Reach camp; learn combat; save the first specialist |
| I | The Iron March | 5–18 | Warlord | Occupied villages, siege roads, fortress interiors |
| II | The Cinder Below | 18–32 | Pyromancer | Ash settlements, mining tunnels, volcanic shrines |
| III | The Hollow Parish | 32–43 | Necromancer | Flooded graves, desecrated chapels, burial halls |
| Finale | The Shattered Threshold | 43–45 | Old God possessing the Necromancer | Break its first incarnation and stop the full awakening |

The main story follows a fixed order: Warlord, Pyromancer, Necromancer, then the Old God's first incarnation. Earlier territories stay available for side quests and exploration. Enemies use authored level bands rather than scaling continuously to every equipment upgrade.

The Warlord supplies prisoners to the Pyromancer's furnaces. The furnaces prepare soul vessels for the Necromancer. The Necromancer believes he can control the Old God, but it possesses him during his final battle. Players destroy this first incarnation and prevent the complete awakening. The surviving Old God becomes the principal enemy of a later campaign, which is not part of this release's production scope.

Foreshadow the chain through military orders, furnace markings, and interrupted prayers. Each area's ruler retains a personal motivation and a complete local story. The possession is a playable, clearly telegraphed final phase, not an unavoidable cutscene defeat.

## Area progression and encounters

Each territory contains four connected zones: an approach, a settlement/dungeon, an optional branch, and the boss stronghold. Zones use authored landmarks, entrances, shortcuts, and story encounters; bounded enemy placement variation adds replayability. Avoid long corridors populated by interchangeable waves.

A typical mission alternates exploration, a small fight, a discovery, a tactical encounter, and a checkpoint. Every encounter has a purpose: teach a threat, combine known threats, protect a route, reveal a character, or test a build. Reinforcements announce their entry and are capped.

### Prologue — The Last Watch

- **Broken Road:** rescue a pinned scout; learn attack, dodge by movement, jump, and cover.
- **Abandoned Watchhouse:** choose an upper rubble route or a guarded doorway. Find the camp's missing supplies.
- **The Tollkeeper:** a deserter captain who demands the wounded be abandoned. Teaches a shielded front, a committed charge, and a punishable recovery.
- **Return to the Vigil:** unlock the quest journal, stash, first gear choice, and one talent point at level 2. Recover the old campaign map.

### Chapter I — The Iron March

| Zone | Main task | Signature encounter | Persistent result |
|---|---|---|---|
| Gallows Road | Reach the occupied village | Shield pair advances under crossbow cover | Rescue a smith or recover the stolen supply wagon first |
| Bannerfall Village | Break the occupation | Disable a signal bell before a bounded reinforcement wave | Smith opens gear upgrades; villagers establish a market |
| The Broken Aqueduct | Optional: free the prisoners | Escort prisoners through cover while a hunter changes firing positions | A rescued guide opens a fortress side entrance |
| Crownless Bastion | Defeat the Warlord | Breach the outer yard, defeat a lieutenant, reach the throne | Camp gains a watchtower; the route to Cinder Below opens |

Named quest bosses: **The Tollkeeper**, **Captain Halvek, the Bell-Keeper**, **The Chain Hound**. Each has a unique mechanic and a recognizable silhouette, not only increased health.

Warlord phases: disciplined shield and spear pressure; banner commands that temporarily improve surviving soldiers; an exposed final phase with slower, broader committed attacks. Destroying banners is an alternative to racing the boss's health. Rescue outcomes affect the route and one support event, not whether the boss is defeatable.

### Chapter II — The Cinder Below

| Zone | Main task | Signature encounter | Persistent result |
|---|---|---|---|
| Ashen Outskirts | Reach the trapped miners | Hounds flush players out of cover while an archer marks shots | Rescued miners reopen a shortcut |
| Furnace Galleries | Shut down the bellows | Vent cycles alternate traversable routes and firing positions | Camp forge gains an elemental crafting recipe |
| The Glass Warrens | Optional: recover a cooling lens | Reflectors redirect an elite's beam; reflections are visibly telegraphed | Lens becomes a utility relic or a boss-room aid |
| Heartfire Cavern | Defeat the Pyromancer | Cross an inactive lava channel and interrupt the final ignition | Camp gains a kiln; the final seal can be assembled |

Named quest bosses: **The Cinder Hound**, **Foreman Rusk, Furnace-Bound**, **The Glass Saint**.

Pyromancer phases: locked fireball lanes; braziers and vent cycles that change safe ground; a final ignition that exposes the boss after a clear evacuation window. Burning altars and jagged spires remain visibly unjumpable. Low platforms are usable shelter, but never permanent immunity to every attack.

### Chapter III — The Hollow Parish

| Zone | Main task | Signature encounter | Persistent result |
|---|---|---|---|
| Drowned Cemetery | Follow the funeral bells | Skeletons rise until their grave lantern is extinguished | A rescued sexton identifies hidden burial paths |
| Chapel of Names | Restore the stolen names of the dead | A cantor shields allies while mourning shades restrict space | Camp memorial lets players revisit recovered stories |
| The Ossuary | Optional: retrieve a family reliquary | Bone guardians separate safe lanes while a collector relocates remains | Choose a protective relic or free a bound spirit ally |
| Mausoleum of the Choir | Silence the Necromancer | Destroy ritual anchors and survive a procession of summoned dead | Camp infirmary improves; grave corruption retreats |

Named quest bosses: **Sister Vey, the Unfinished Prayer**, **The Bone Collector**, **The Nameless Mourner**.

Necromancer phases: deliberate summons with visible summoning areas; ritual anchors that make certain minions return; a final procession with moving safe lanes. Summons have a strict concurrent cap. Solo players can perform every ritual interaction without simultaneous switches.

## Optional progression beyond the ending

Levels 46–60 come from unfinished town stories, optional quest bosses, elite contracts, and selectable rematches of existing bosses with authored modifiers. Keep the initial post-story offering finite and focused; an infinite procedural endgame is not required.

- The level-45 finale must be beatable with ordinary chapter-appropriate gear and a coherent build. No level-60 items or cap-level talents are required.
- Earlier story encounters do not automatically scale to 60 when the player levels. Returning stronger is intentional. Harder rematches are explicitly selected.
- Extra levels provide additional talent choices, refinements, and modest stat growth. Avoid abrupt power cliffs that invalidate a level-45 character.
- Optional quest rewards include authored equipment and recipes, with deterministic acquisition paths. Do not use rare-drop grinding as the only route to progression.
- Level-band recommendations for the three territories are starting targets. Validate solo and co-op completion around 45 in playtests before claiming the balance is achieved.

## Enemy hierarchy

| Tier | Job | Examples | Reward and rules |
|---|---|---|---|
| Lesser | Pressure and readable group composition | Levy soldier, skeleton, ember hound | Small XP and materials; no individual loot flood |
| Greater | Change the player's tactical priority | Shield bearer, grave cantor, cinder archer | Distinct silhouette and at least one authored ability |
| Elite | Test positioning and target selection | Banner champion, reliquary guard, furnace brute | One modifier initially; visible name and guaranteed useful reward |
| Quest boss | Resolve a local story | Halvek, Bone Collector, Glass Saint | Bespoke mechanic, quest outcome, first-clear reward |
| Area boss | Complete a territory | Warlord, Necromancer, Pyromancer | Multiple phases, checkpoint, signature item choice |

Initial enemy roster target: four functional roles per territory plus three named encounters. Existing sprites can support prototypes, but roles that require different tells must gain distinct colors, silhouettes, or accessories before release.

Elite modifiers: **Bulwark** (directional defense), **Hexbound** (a breakable tether), **Volatile** (delayed marked death explosion), **Commander** (a nearby support banner). Do not stack arbitrary speed, healing, immunity, and damage modifiers. Elites should introduce an answerable problem, not a health sponge.

## Characters, levels, and talents

Keep Knight, Mage, and Rogue. Each remains capable of finishing alone. Co-op benefits from control, protection, and burst combinations; no mandatory healer or tank slot.

- Confirmed Part I level cap: 60; normal-difficulty campaign completion target: approximately 45. Proposed talent cadence: one point at every even level from 2 through 60 (30 total; 22 available at level 45).
- Class abilities begin functional. Progression changes their behavior rather than withholding the class's identity until late game.
- Three branches per class, seven nodes per branch. Proposed ranks: three early nodes with up to three ranks each, three one-point advanced nodes, and one one-point capstone (13 points per branch, 39 across the class). A 30-point cap-level character cannot purchase everything.
- Advanced choices require four points in that branch. A capstone requires eight branch points and character level 24. Only one capstone may be equipped at once.
- Free respec at camp; saved loadouts later. All talent values are campaign-specific.

| Class | Branch | Play style | Example capstone |
|---|---|---|---|
| Knight | Bulwark | Guarding, counters, ally protection | **Hold the Line:** a well-timed block grants a short shared barrier |
| Knight | Vanguard | Cleave, stagger, aggressive positioning | **Unbroken Advance:** staggered targets enable a follow-up cleave |
| Knight | Oathkeeper | Self-sustain, rally effects, endurance | **Last Vigil:** Iron Resolve can avert a lethal hit once per encounter |
| Mage | Ember | Fire Lance, burns, controlled burst | **Piercing Dawn:** Fire Lance pierces one target with reduced follow-through damage |
| Mage | Rime | Slow zones, shatter windows, safe spacing | **Still Winter:** Frost Ring briefly roots chilled lesser enemies; bosses gain stagger pressure instead |
| Mage | Aether | Barriers, efficient casting, utility | **Shared Ward:** Mend also shields the nearest wounded ally; strengthens the self-shield in solo |
| Rogue | Duelist | Precision, single-target pressure | **Marked for Death:** repeated deliberate hits set up a burst window |
| Rogue | Nightwalker | Shadowstep, repositioning, evasion | **Through the Veil:** a successful evade refreshes a limited-use Shadowstep charge |
| Rogue | Saboteur | Traps, debuffs, area control | **Patient Hunter:** a triggered trap empowers the next Twin Daggers cast |

Example Ember branch nodes: Kindling (longer burn), Clean Release (faster recovery), Banked Heat (small post-kill shield), Forked Ember (reduced-damage secondary spark), Tempered Flame (casting while moving improves control), Cinder Echo (burn expiration causes a small burst), Piercing Dawn. No infinite cooldown refunds; proc chains cannot trigger themselves.

## Gear and crafting

Five equipment slots: weapon, armor, boots, charm, relic. A visible primary benefit and at most two secondary affixes keep loot readable on iPhone. Equipment changes attacks or decisions more often than it supplies tiny statistical upgrades.

| Rarity | Purpose |
|---|---|
| Common | Reliable baseline; mostly materials after the opening |
| Uncommon | One clear stat or utility improvement |
| Rare | Two useful affixes, appropriate to the current chapter |
| Named | A distinctive authored behavior, with a fixed first-clear acquisition path |

Starting item pool target: 12 named items and 24 base items shared across appropriate class pools. Area bosses offer a choice among three class-compatible rewards. Optional quest bosses award a named item or its recipe; no mandatory rare drop gates the story.

Example items:

- **Bellkeeper's Guard:** a successful block weakens the next incoming hit; Knight weapon.
- **Pilgrim's Brand:** Fire Lance leaves a small ember patch with a capped duration; Mage weapon.
- **Graveglass Charm:** moving out of a marked attack grants a short shield, with an internal cooldown.
- **Ashwalk Boots:** shorten burn duration; do not grant lava immunity.
- **The Mourner's Thread:** revive an ally faster; in solo, shorten the recovery interaction after a checkpoint defeat.
- **Chainbreaker:** Twin Daggers deal increased stagger to greater enemies; Rogue weapon.
- **Cooling Lens:** reduce one vent cycle's pressure through an interaction, or equip a modest fire defense bonus. The quest makes this choice explicit.

Crafting uses gold, salvage, and one material per territory. Upgrade an item through three visible ranks; let players reroll one affix at a capped cost. No durability repairs, daily timers, or crafting wait times. Early equipment remains viable with upgrades but does not make all later rewards irrelevant.

Inventory: 24 backpack spaces initially, a shared account stash, gear comparison, favorite protection, and bulk salvage previews. Never auto-salvage equipped or favorited equipment. Quest items live outside the backpack.

## Quests and the living camp

Journal sections: main story, local quests, companion stories. Track one quest on the battlefield, showing one next action. Optional objectives can grant permanent routes, NPC services, or alternative rewards. Avoid repeated kill-count chores as the main content.

Core NPCs:

- **Mara, the Scout:** routes, enemy intelligence, and the main quest board.
- **Oren, the Smith:** gear upgrades; his rescue lights the camp forge.
- **Sister Elian:** infirmary, talent respec, and the Parish story.
- **Tamsin, the Quartermaster:** stash, consumables, and recovered supply rewards.

Camp changes happen after explicit milestones: tents become workshops, rescued characters appear, lanterns and memorials accumulate, and the chant gains restrained layers. Camp services do not require waiting for another online player to finish a long menu.

Sample branching quest — **A Bell for the Living**:

1. Find the village's captured bell-ringer.
2. Learn that ringing the bell frees the prisoners but alerts Halvek.
3. Choose to ring it now (reinforced courtyard, prisoners rescued immediately) or silence the signal station first (longer route, safer rescue).
4. Both routes can save the prisoners. The difference is risk, route, dialogue, and a small reward variation.
5. Complete the quest at camp; unlock a guide or supply service. Store a stable choice flag rather than trying to infer the outcome from enemy counts.

## Bannerfall: the war-town hub

Bannerfall is a persistent, walkable town affected by the Warlord's occupation. It begins damaged and partially closed. Helping its people opens shops, restores services, changes dialogue, and makes the streets visibly safer. Vigil Camp remains the refuge and travel hub; Bannerfall is the first substantial settlement with its own inhabitants and problems.

The core loop is: speak to a resident, choose a quest, prepare equipment, explore or fight, return with results, gain XP and rewards, manage the character, then choose the next lead. Story quests drive the campaign; town quests give context, build options, and alternative routes. Players should know why a person needs help before an objective marker appears.

### First town quest set

| Quest | Resident | Playable objective | Rewards | Town consequence |
|---|---|---|---|---|
| Bread Before Blades | Anja, the baker | Recover stolen flour; choose stealth through the mill or fight the supply patrol | XP, gold, food consumables | Bakery reopens; civilians return to the square |
| The Smith's Son | Oren, the smith | Track a prisoner convoy and free his apprentice son | XP, a class-compatible equipment choice | Forge opens; father and son appear together |
| Names on the Wall | Elian, the healer | Find three missing residents through evidence and encounters, not random drops | XP, healing supplies, a charm choice | Infirmary and memorial change based on whom players find |
| A Debt in Iron | Tamsin, the quartermaster | Retrieve a seized merchant ledger and confront the corrupt collector | XP, gold | General store opens with a permanent modest discount |
| Beneath the Cistern | Pell, the well keeper | Investigate disappearances beneath town; defeat the Chain Hound | XP, a named item or recipe choice | Clean water returns; underground shortcut opens |
| The Silent Bell | Mara, the scout | Disable the signal station before the main rescue, or accept a harder courtyard fight | XP, salvage, route advantage | Changes A Bell for the Living's encounter composition |
| Letters Never Sent | Dain, the veteran | Recover dispatches and choose whether to expose the officer who withheld them | XP, a utility item | Resident dialogue changes; evidence foreshadows the Pyromancer |
| After the Banners Fall | Anja and Oren | After the Warlord's defeat, recover building supplies from a remaining patrol | XP, upgrade materials | Rebuild the market; unlock one later-region merchant contact |

Quest rewards are authored and granted once per character. Essential services are unlocked by the main route or accessible side quests; no irreversible choice permanently removes the only equipment vendor. Unfinished town quests remain available after the area boss unless a time-sensitive outcome was explicitly explained beforehand. Do not impose hidden real-time deadlines.

### XP and leveling

- XP comes from encounters, completed quests, significant discoveries, elites, and bosses. Quest completion is a substantial source; conversational and investigation quests also grant XP.
- Author the XP curve for levels 1–60 using chapter XP budgets. Main-story objectives and required encounters must support completion near level 45 without mandatory side-quest grinding. Tune optional levels 46–60 separately; the previous level-20 formula is retired.
- A standard side quest grants roughly 20–30% of the next-level requirement at its authored recommended level. Short errands grant less; multi-stage stories and quest bosses grant more. Reward amounts are fixed when content is authored, not recalculated to exploit turn-in timing.
- Target the main route to keep a player within each chapter's recommended band. Completing several local quests should provide about one or two extra levels and broader equipment choices, not require hours of grinding.
- Levels grant class-appropriate base-stat growth; even levels grant a talent point starting at level 2. Do not add a second, redundant attribute-point system initially.
- Show XP gained, the progress bar, and unspent talent points clearly. A level-up does not force a modal screen during combat. Spend points in safety.
- Party members participating in the encounter receive full personal XP within the encounter's participation area, with no last-hit competition. Eligible quest completion credit is tracked individually and awarded once. An absent guest does not gain unlimited shared town XP.
- One-time discovery XP, encounter completion IDs, and reward transaction IDs prevent save reloads or reconnects from duplicating rewards. Summoned enemies have reduced or no XP and cannot be farmed indefinitely.

### Character and equipment management

Open a Character panel with four clear tabs: Overview, Equipment, Talents, and Inventory. The Journal is a separate entry so players can check an objective quickly.

Overview shows class, level, XP, health, damage, attack interval, skill cooldowns, defenses, and active modifiers. Separate permanent stats from temporary effects. Explain what each stat affects; avoid a single misleading power-score number.

Equipment shows weapon, armor, boots, charm, and relic. Selecting an item compares it against the equipped item, with actual stat changes and unique-effect descriptions. Support Equip, Unequip, Favorite, Sell, and Salvage where appropriate. Class restrictions and level requirements are visible before purchase. Inventory sorting supports slot, rarity, and newest. Quest objects and crafting materials do not consume ordinary item slots.

Changes to equipment and talents are allowed in town, camp, and safe checkpoints. During combat, inspection is allowed but changes are locked with a clear explanation. Solo may pause in management screens; online menus do not pause the shared world. Use tap-to-select and explicit buttons on iPhone, not mandatory drag-and-drop.

### Merchants, buying, selling, and crafting

- Oren sells class-appropriate weapons and armor and performs upgrades. Tamsin buys ordinary gear and sells supplies. Anja sells food. Later towns add specialized stock rather than replacing these characters.
- Shops use personal stock eligibility and personal gold, so another player cannot buy the only useful item before a guest sees it. Shop unlocks follow the host's world, while purchase transactions belong to the buyer.
- Initial pricing rule: buying costs 100% of an item's base price; selling returns 25%. Quest discounts apply to purchase prices and remain capped at 15%, preventing buy/sell profit loops. All values need economy playtests.
- The Sell screen shows the selected items and total gold before confirmation. Equipped and favorited gear are excluded from bulk sales. A named item prompts an additional warning with its effect shown.
- Keep a persistent personal buyback list of the last 12 sold item instances. Buyback costs exactly the gold received and restores the same upgrades and affixes. State the limit clearly; avoid invisible expiry while a player is reading menus.
- Selling and salvaging are alternatives: gold funds supplies and services; salvage funds upgrades. Neither action silently happens when collecting new loot.
- Show purchase affordability, empty inventory space, and a comparison before spending. A full backpack prevents purchase or offers stash transfer; it never deletes the purchased item.
- Server-authoritative, atomic transactions update currency and item ownership together. Repeated input, reconnects, or concurrent shop actions must not duplicate items or gold.
- No player-to-player trading in the first release. It can be designed separately once saving and ownership are reliable.

### First playable slice additions

Bannerfall Village must include a small usable town square, two residents with complete side quests (The Smith's Son and Bread Before Blades), a merchant with buy/sell/buyback, a working XP bar and level-up flow, and character/equipment management. The remaining town quests expand after the core slice is playable. Acceptance: complete a quest, level up, spend a talent point, equip a reward, sell an old item, buy it back, save, reload, and retain exactly the correct items, currency, XP, and quest status in solo and two-player co-op.

## Online co-op rules

Separate devices, one shared world. Initial release supports two players; interfaces and encounter data allow up to four without promising four-player performance before measurement. Private invite codes first; public matchmaking and trading are out of scope for the first campaign.

- Each player owns a persistent character, gear, XP, talent allocation, and quest completion ledger.
- The party enters the host's campaign world. Joining a later chapter clearly states its spoiler/progress implications.
- Guests receive loot and first-clear credit. Main-story advancement applies only when their prerequisites are met; otherwise record completion credit without skipping required story steps.
- Loot is personal. One player cannot take another's drop. Difficulty and loot rolls are fixed for an encounter at its start; joining/leaving cannot reset or multiply rewards.
- Story choices are proposed to the party; the host confirms after everyone has had a chance to read the choice. Show whose world is being changed.
- All interactions work solo. Co-op may accelerate a lever, protect a reviver, or combine skills, but never requires two simultaneous switches.
- Downed players can be revived with a four-second interruptible interaction. Personal healing cannot create infinite revive chains. A party wipe returns to the last checkpoint with durable quest progress intact and the current encounter reset.
- Solo defeat restarts the encounter at the checkpoint; equipped gear is never lost. Normal/story difficulty has no consumable corpse-recovery requirement.
- Joining occurs at camp or a checkpoint. Mid-boss reconnect restores the same character and reward eligibility, not a fresh extra player.
- Proposed disconnect grace period: 60 seconds. A disconnected character becomes noninteractive; the server preserves the encounter roster. Solo a player may pause; online, menus never pause other players.
- The server owns the session, so a host disconnect does not immediately destroy the world. Another member can become party leader; durable world choices remain attached to the original campaign save until the session ends.

Co-op tuning starts with +65% ordinary enemy health and +75% boss health per additional player, not multiplied enemy damage. Slightly increase composition variety where performance permits. Cap encounter population and avoid stacking every enemy's targeting on one player. These values need playtesting, especially with revive access and crowd control.

## Saving and technical approach

Online co-op requires a network service; the current local HTML build cannot provide shared, authoritative worlds by itself. Keep Canvas and JavaScript for now. Design the simulation so a Node.js server can execute the same combat rules without DOM, rendering, audio, or localStorage dependencies.

1. Separate game mode, content definitions, simulation, presentation, and persistence. Campaign and Gauntlet must not share a single mutable balance table.
2. Define stable IDs for zones, encounters, quests, items, talents, players, and rewards.
3. Use fixed simulation ticks; clients send sequenced input commands, not damage or loot results. The server resolves movement, collision, hits, drops, XP, and quest completion.
4. Start with a 30 Hz authoritative simulation and 10–15 Hz snapshots, subject to profiling. Predict local movement and reconcile gently; interpolate remote actors. Do not add animation state to the combat authority unless it affects timing.
5. Share seeded encounter content and compact state deltas; assets remain client-side. Route finding should be bounded and reused where possible rather than running a full search per enemy per tick.
6. Introduce versioned character and campaign save schemas. Autosave at checkpoints, quest decisions, loot awards, and camp changes. Item/reward grants must be idempotent across retries and reconnects.
7. Prototype locally with two clients and a local server before selecting hosting, accounts, databases, or costs. Do not expose a developer server publicly as the final co-op service.
8. Release online worlds over HTTPS/WSS with authenticated sessions, expiring invitations, server-side input limits, and durable saves. File links remain useful for offline Gauntlet previews, not cross-device co-op delivery.

Save split:

- Character: class, level, XP, talents, inventory/equipment, personal quest rewards.
- Campaign: territory unlocks, checkpoints, world choices, NPC rescue flags, boss defeats.
- Session: party membership, active encounter, transient projectiles, downed state, reconnect window.

Offline solo can use a local authoritative simulation and local saves initially. Import/export provides backup. Do not promise seamless offline/online character transfer until conflicts and reward validation have an explicit policy.

## First playable chapter: concrete scope

Build **The Bell at Bannerfall**, a 20–30 minute slice, before creating the whole world.

- One persistent campaign character per class; levels 1–5.
- Camp with Mara, Oren, a stash, gear comparison, and six prototype talent choices per class. Capstones remain locked.
- Three small authored maps: Broken Road, Bannerfall Village, Bastion Courtyard.
- Four enemy roles: levy, shield bearer, crossbow soldier, banner support; one elite modifier.
- Main quest A Bell for the Living; optional rescue of Oren.
- Halvek as a quest boss and a two-phase Warlord as the chapter boss.
- Five equipment slots, eight obtainable items, one guaranteed boss reward choice.
- Checkpoint/death recovery, save/load, and a clear campaign exit back to the menu.
- Two-player private online session: invite, movement replication, authoritative combat, personal loot, revive, disconnect/reconnect, checkpoint join.
- iPhone joystick, Auto toggle, skills and jump remain available. Use large comparison panels and avoid inventory drag-and-drop as the only interaction.

The full prologue and final geographical layout can expand after this slice proves the loop. The slice temporarily places the Warlord earlier; do not mistake prototype pacing for final campaign progression.

## Build order and acceptance gates

1. **Mode and save foundation:** separate Campaign from Gauntlet; make one character persist through reload and migrate a previous save without losing items.
2. **Authoritative simulation seam:** move combat/state stepping out of browser-only code; run repeatable input replays and compare outcomes.
3. **Playable solo slice:** complete the quest, equip a reward, allocate a talent, defeat the Warlord, and resume from a checkpoint on PC and iPhone.
4. **Two-player slice:** play the same chapter across two clients; check latency, cover collisions, damage, simultaneous loot, revives, and reconnect. Never duplicate quest or item rewards.
5. **Campaign expansion:** finish Iron March, then build Cinder Below and the Parish, then the finale. Add branches only when their main routes are playable.
6. **Polish and broader co-op:** accessibility, difficulty, network smoothing, four-player load tests, and optional post-campaign hunts.

Performance targets to measure: stable 60 fps on a representative desktop; stable 30 fps minimum on the selected oldest supported iPhone. Set concrete device/browser support after profiling. Test touch UI in portrait and landscape, long sessions, suspended tabs, low battery mode, and actual network latency.

## Boundaries for the first release

No procedural infinite endgame, public matchmaking, auction house, player trading, guilds, open PvP, mandatory daily quests, or dozens of random gear affixes. These would compete with the authored campaign, reliable saves, and co-op foundations.

The design succeeds when an area has a memorable place, a tactical enemy mix, a local story with consequences, a rewarding build choice, and a boss that feels like its ruler—not merely another room full of higher health bars.
