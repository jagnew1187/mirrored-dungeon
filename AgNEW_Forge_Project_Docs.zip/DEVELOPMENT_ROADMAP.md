# Mirrored Dungeon — Development Roadmap

**Studio:** AgNEW Forge (working) · **As of:** 2026-10-25  
**Purpose:** A practical implementation queue for Codex; approved design lives in `GAME_DESIGN_BIBLE.md`.  
**Important:** This is a plan, not proof of feature completion. Read the repository and `CHANGELOG.md` before coding.

## Working agreement

**ChatGPT + creator:** worldbuilding, narrative decisions, game mechanics, priorities, player-experience acceptance criteria.  
**Codex:** inspect repository, implement scoped tickets, write/update tests, report real results and update the changelog.  
**GitHub:** code/asset history and source of truth for completed work.

### Rules for Codex

1. Start by inspecting current files, manifests, scripts, docs, current Git status and existing tests. **Do not overwrite working systems or invent finished status.**
2. Read the relevant Game Design Bible sections; use the detailed campaign proposal in its appendix only when needed.
3. Each work session should target **one milestone or tightly scoped ticket**. Prefer a small reviewed commit over a giant rewrite.
4. Run available tests and a local playable build. Distinguish automated tests, manual tests and untested hardware.
5. Preserve existing save data with tested migrations and avoid duplicating item, XP or quest rewards.
6. Update `CHANGELOG.md` after actual changes with date, files/commit reference if known, verification performed and known gaps.
7. For conflicting designs, write a concise question or blocker; don't produce a new lore bible or add speculative mechanics unasked.

## Priority 0 — Repository truth check (first Codex task)

**Goal:** Reconcile what exists now with what is only planned. No large feature changes in this task.

- [ ] Inventory modes and navigation entry points: Arena / Campaign / Endless Descent, if present.
- [ ] Identify which classes, abilities, encounter systems, art, NPCs, quests, inventory, XP, talents, saves and payments hooks exist.
- [ ] Distinguish the simulated rival from actual networked players; locate server code if any.
- [ ] Check existing tests/build commands, deployment setup and iPhone testing mechanism.
- [ ] Identify text-based mission-deployment entry points and the reusable quest/world data behind them.
- [ ] Establish one quick smoke test per existing playable mode.
- [ ] Record audit findings and gaps in `CHANGELOG.md` or a concise audit note; do not mark unverified features as completed.

**Gate:** A reliable implemented/not implemented/uncertain status table and an existing working build.

## Priority 1 — Protect the current campaign foundation

**Goal:** Make progress safe to refactor.

- [ ] Back up or migrate existing local class saves; prove inventory, gold, buyback, XP, talents, and quest flags survive save/reload.
- [ ] Preserve the two reported Bannerfall quests, Warlord encounter, character selection, progression, and menu entry.
- [ ] Add state IDs for quests, zones, encounters and rewards if currently missing.
- [ ] Write regression tests for one-time rewards, restart/checkpoint and duplicate item prevention.
- [ ] Avoid changing Arena combat balance while rebuilding Campaign navigation.

**Gate:** Save/reload of existing campaign progress works before and after a schema update; no lost purchases or duplicate loot.

## Priority 2 — Walkable Vigil Camp (first creative vertical slice)

**Goal:** Player can physically explore camp rather than select a mission from a deployment list.

- [ ] Build a compact walkable camp map using the established 16-bit-inspired, moderately higher-detail pixel-art visual language.
- [ ] Place a real interactable protected chest/stash, campfire and the minimum existing useful NPCs/services.
- [ ] Reuse existing inventory, merchant, talent and quest logic in small interactions.
- [ ] Add readable mobile interaction prompts and safe-zone behavior.
- [ ] Provide a world exit leading toward the Broken Road; retain menu exit and local saves.

**Gate:** Start Campaign → walk around Camp → use chest/NPC → save/reload → walk toward the road on desktop and in mobile layout.

## Priority 3 — Connected road and Bannerfall town

**Goal:** The player reaches real quests by walking, rather than choosing a text mission deployment.

- [ ] Implement a stable authored **Broken Road → Bannerfall Village** transition, with walkable terrain, obstacles, appropriate encounters and one optional discovery.
- [ ] Build a usable Bannerfall square with quest-givers, signs of occupation and persistent NPC/world state.
- [ ] Reuse the *The Smith's Son* and *Bread Before Blades* quest objectives. Convert mission markers into world interactions and journal tracking, preserving rewards.
- [ ] Quest completion triggers tangible town consequences (shop access, people returning, etc.) where specified.
- [ ] Support return to Camp and safe checkpoint respawn without resetting completed one-time quests.

**Gate:** Finish both quests through exploration, collect rewards, level up, spend a talent point, sell/buy back an item, exit/reload and retain correct state.

## Priority 4 — Finish the Warlord's physical dungeon path

**Goal:** World navigation leads to a full challenge and boss payoff.

- [ ] Put an accessible **Crownless Bastion** entrance into the authored region.
- [ ] Finish Warlord **Armory/Barracks gauntlet → Throne Room** with stable collision layers and enemies.
- [ ] Preserve boss combat and inheritance where used, with correct mode-specific rules.
- [ ] Optional gauntlet route shows exact **benefit + drawback + duration** before commitment; skipping it remains viable.
- [ ] Validate Knight, Mage and Rogue; test direct and reward routes and no softlocks.
- [ ] Record boss flags, town/camp consequences and Warlord rewards durably; keep earlier regions replayable.

**Gate:** From camp, walk through the town/fortress, defeat Warlord, return safely, reload with correct world state. Character completion works in three classes.

## Priority 5 — Test & harden the first full single-player loop

- [ ] Profile collision/pathfinding, hazard tells, touchscreen ergonomics and FPS with real iPhone testing when available.
- [ ] Fix basic encounter difficulty spikes and substantial-buff route dominance using measured clear times, deaths and damage.
- [ ] Check long-session stability, backgrounding/suspended tab behavior, checkpoints and save consistency.
- [ ] Keep Arena mode playable with its own balance and short race loop.

**Gate:** One repeatable 20–30 minute Campaign experience that feels like a world, not a menu, plus no Arena regressions.

## Priority 6 — Actual two-player co-op foundation

**Do not claim online co-op is implemented until demonstrated on two different devices.**

- [ ] Separate simulation from rendering/browser state to allow server authority.
- [ ] Build/verify a local test server and two browser clients; sync movement, collision, combat and enemy state.
- [ ] Add private invites, personal item/XP ownership, host world choices, revived/downed state, checkpoint joining and reconnect consistency.
- [ ] Test item/XP idempotency and cross-device latency; account for disconnected hosts.
- [ ] Select production hosting/security only after prototype proves reliable.

**Gate:** Two independent devices complete the Bannerfall slice together without duplicated rewards or a broken save.

## Priority 7 — Expand authored Part I

- [ ] Finish Iron March side zones, occupants, story bosses and camp/town rebuild changes.
- [ ] Build **Cinder Below**: Ashen Outskirts → Furnace Galleries → Glass Warrens (optional) → Pyromancer's Lava Cave/Sanctuary.
- [ ] Build **Hollow Parish**: Drowned Cemetery → Chapel of Names → Ossuary (optional) → Halls of the Dead/Necromancer's Crypt.
- [ ] Build **Shattered Threshold**, the playable possessed-Necromancer/Old God finale, with a satisfying Part I ending.
- [ ] Tune mainline XP toward ending near level 45; keep levels 46–60 optional and area bands authored.

**Gate:** Part I is playable start-to-finish in solo; co-op support is expanded and tested as systems mature.

## Later work / do not distract the next milestone

- Arena: opponent minimap, visible-reinforcement pacing, cosmetic emotes, match telemetry; preserve seeded competitive fairness.
- Endless Descent: Camp return, chest, repeatable floors, progression and salvage; scope separately from the authored campaign.
- Store: one-time **$4.99** ad removal, optional character/map skins and emotes; no combat monetization. Never interrupt combat with ads.
- AgNEW Forge branding: game startup identity and logo integration after choosing final art/brand rights.
- Parts II and III: story direction exists; implementation begins only after Part I foundation proves viable.

## Template for one Codex work request

```text
Read GAME_DESIGN_BIBLE.md (relevant sections), DEVELOPMENT_ROADMAP.md, and CHANGELOG.md.
Inspect the current repository before editing.
Implement ONLY Roadmap Priority [N], or the named subsection [X].
Preserve existing working features and save data. Write or update appropriate tests.
Run available tests and provide exact results; do not claim device testing unless performed.
Update CHANGELOG.md with the actual change, relevant files/commit and verification.
Do not expand lore or introduce additional features beyond the approved design.
Report: implemented, tested, outstanding/blockers, suggested next narrow task.
```
