# Mirrored Dungeon — Change Log

**Studio:** AgNEW Forge (working) · **Initialized:** 2026-10-25  
**Purpose:** Actual implementation history and verifiable test results. This is **not** a wish list; planned features belong in `DEVELOPMENT_ROADMAP.md` and design belongs in `GAME_DESIGN_BIBLE.md`.

## Status legend

- **Repository-verified:** Code/asset/tests inspected and reproducible, with commit or file reference.
- **Developer-reported:** User or Codex reported functional work; repository has not been inspected as part of creating this document.
- **Design only:** Approved/planned concept; NOT an implemented feature.
- **Unknown:** Needs an actual repository audit.

## 2026-10-25 — Documentation baseline (created outside repository)

**Status:** Documentation created; game source not inspected.

- Added `GAME_DESIGN_BIBLE.md`, preserving the detailed campaign proposal plus newer open-world, gauntlet and monetization direction.
- Added `DEVELOPMENT_ROADMAP.md` with implementation priorities and acceptance checks.
- Initialized this `CHANGELOG.md` with only previously reported milestones and explicit uncertainty.
- **Verification:** Files created and checked locally; not committed to GitHub. No game build or device test performed in this documentation step.
- **Next:** Codex audits live repository and replaces unknown/reported statuses with code-and-test evidence.

## Prior milestones — reported, not repository-verified

### 2026-10-18 — Early browser prototype

**Status:** Developer-reported from earlier project discussions.

- Standalone browser-playable HTML/JavaScript prototype with a simulated opponent, Mage attacks/movement, three bosses, boss-order inheritance, reinforcement timers, pause and restart.
- Later discussions refer to Knight, Mage and Rogue as playable classes, animated pixel-art sprites, and mobile-layout work.
- **Known limitation:** Animation design needs polish; frame overlap/bleeding had been mentioned earlier. Current fix status is not independently verified.

### 2026-10-22 to 2026-10-25 — GitHub / Codex development in progress

**Status:** User-reported.

- User placed game in GitHub and opened work in Codex.
- Sprite frames were described as looking better, with some animation design issues left intentionally for later.
- User used Codex to create additional campaign functionality, but its exact present commit state has not been reviewed here.

### 2026-10-25 — Reported first campaign foundation

**Status:** User-provided development report; repo/build not checked.

- Two Bannerfall quests and a Warlord encounter reported playable.
- XP, equipment, selling, buyback, and initial talents reported implemented.
- Local saves by character class reported implemented.
- Level cap target is 60; opening slice reportedly reaches approximately level 4.
- Developer report stated desktop, phone-layout, save and combat checks passed. **Actual physical iPhone hardware testing is not established by that report.**
- Report explicitly said online co-op and the full level-45 storyline remained unfinished.
- User subsequently requested conversion from text-based mission deployment into **walkable open-world exploration**. This request is **design direction**, not proof of implementation.

## Feature verification queue

| Feature | Current documented status | Evidence needed |
| --- | --- | --- |
| Original Arena race against computer rival | Developer-reported | Run locally; inspect encounter code |
| Knight / Mage / Rogue selectable and playable | Developer-reported | Test all classes in each accessible mode |
| Sprite animations and mobile layout | Developer-reported | Inspect assets, game rendering and iPhone controls |
| Two Bannerfall quests and Warlord encounter | Developer-reported | Inspect quests, reproduce completion and persistence |
| XP, equipment, vendors, buyback, initial talents | Developer-reported | Save/reload/economy regression test |
| Walkable Camp and connected overworld | Design only / unknown | Inspect current map/navigation implementation |
| Themed full gauntlets and meaningful buff detours | Design only / unknown | Play every route, check buffs and drawbacks |
| Two-device actual online Campaign co-op | Not confirmed shipped | Two independent devices, network session test |
| Full Part I level-45 story | Not complete per report | End-to-end campaign playthrough |
| Live ads, $4.99 unlock and purchasable cosmetics | Design only | Validated store and payment restoration tests |
| AgNEW Forge intro/logo in the build | Design only / unknown | Inspect rendered assets and app screens |

## How Codex should update this log

For each merged change, add a dated entry at the **top** of the log in this format:

```md
## YYYY-MM-DD — Descriptive milestone

**Status:** Repository-verified (or developer-reported, if not reproduced)
**Commit / PR:** <hash or link, if available>
**Changed files:** <relevant paths>

**Implemented:**
- Specific working code/feature, without marketing language.

**Verification:**
- Exact command(s) and whether they passed; any real device/browser checks.

**Known limitations:**
- What did not work or wasn't tested.

**Next:**
- One scoped development task.
```

### Integrity rules

1. Never mark a feature shipped just because it appears in a prompt, concept image or design file.
2. Don't retroactively invent commit hashes, test logs, dates or completion claims.
3. If a feature is partially done, say exactly what works and what does not.
4. Report regression failures and migrations honestly; don't silently remove them from the history.
5. `CHANGELOG.md` should grow alongside **working code**, while `DEVELOPMENT_ROADMAP.md` carries upcoming tasks.
