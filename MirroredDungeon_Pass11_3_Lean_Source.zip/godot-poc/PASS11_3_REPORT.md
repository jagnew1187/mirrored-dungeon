# Pass 11.3 — directional transitions and compact conversations
2026-11-01 · Current project: `godot-poc/project.godot`

## Changes
**Transitions:** exits previously passed only a destination map to `enter_area`, so every visit used that map's default spawn. Explicit stable exit/entrance pairs now connect Vigil ↔ Old Mill Road and Old Mill Road ↔ Bannerfall. The existing Bannerfall → Vigil shortcut is retained and paired with a south-camp return shortcut. No terrain, buildings, map scenes or sprites were replaced.

`map_transitions.gd` defines destination map, entrance and inward facing vector. Arrival is placed 96 pixels inside the paired entrance, preserving up to 48 pixels of lateral offset. Deterministic nearby clearance checks avoid static obstacles/NPCs and provide up to six distinct safe placement positions for future companions. Only the existing protagonist is spawned. Camera positioning follows arrival, respecting existing map bounds. A 0.6-second simulation-time guard prevents immediate reverse activation; deliberate return works after the guard. Entrances remain explicit tap/E interactions, not automatic edge triggers.

Missing entrance references return a warning; live failed arrival logs and displays it, then searches around the checkpoint spawn as a documented fallback. Missing source link metadata refuses transition with a warning. Default spawn remains for new games, explicit recovery, the existing menu's Return to Vigil, test setup, and Continue at the saved safe checkpoint. Continue still restores saved health before autosave; exact departure coordinates were never saved and no new save schema was introduced.

**Dialogue:** ordinary conversations now use a bottom panel occupying 33% of desktop height, with the game world visible and no full-screen veil. A small top-aligned portrait, speaker name, readable text and Continue replace the menu-style header and oversized portrait. On smaller screens the panel adapts to 45% height (55% in short landscape viewports). Long text and response choices scroll inside the panel; Continue/Leave remains reachable. An optional choice list supports callbacks and next dialogue nodes without adding any production dialogue or quest content. Existing Mara/Anja quest triggers remain in `main.gd` unchanged. Menu pause/input clearing is reused; mouse, keyboard Enter/Escape and touch work without passing movement/attack input into the world.

## Verification
**647 checks passed:** pass113 57; pass06_campaign 30; pass09 110; pass11 145; pass111 7; pass112 16; pass05 66; pass102 164; pass06 52. The new 57 checks also pass in rendered Godot. Logs: `tests/pass113-pass*.txt`, `tests/pass113-rendered.txt`. Local certificate-store warning only in rendered stderr.

Coverage: all six paired directions, corresponding entrance rather than default spawn, facing, lateral offsets, safe six-person placement seam, reverse guard, camera position, missing entrance result, generic four-direction placement, dialogue quest trigger, mouse/Enter/touch, one-time branching callback, close/input reset, save round trip, phone/tablet bounds at 85/100/115%, existing combat/equipment/roster/talents and the full campaign route for all three protagonists. No assertions were removed. An initial guard based on wall-clock time failed accelerated campaign routes; using simulation time and resetting it on fresh area loads corrected that failure.

Genuine engine captures:
- [Return from Bannerfall at the road's eastern entrance, facing west](tests/pass113-captures/road-east-arrival.png)
- [Ordinary Mara conversation on desktop](tests/pass113-captures/compact-mara-desktop.png)
- [Phone scroll stress fixture using repeated existing text and test-only choices](tests/pass113-captures/compact-mara-phone.png)

## Manual acceptance
1. Restart the workspace project (window title still says Pass 11).
2. Leave Vigil east: arrive at the road's western entry, facing east. Return: arrive beside Vigil's eastern exit, facing west.
3. Walk the road to Bannerfall and return; verify the eastern road entrance and west-facing arrival. Try the retained Bannerfall/Vigil shortcut in both directions.
4. Cross near either side of each entrance; confirm offset and clear ground. Immediately click back, then retry after a short pause; no automatic loop should occur.
5. Talk to Mara, the twins and Anja. Verify visible world, name/portrait, scrolling and unchanged quest consequences. Close with Continue, Enter, Escape and tap; movement and attacks should resume only on fresh input.
6. Check 390×844 and 844×390 layouts, then equipment/roster menus, combat and wounded-save Continue.

## Preservation and limits
Complete pre-change checkpoint: `checkpoints/pre-pass11_3-20261101/` (1,754 files, hash manifest and Git status). Existing archives, player profiles and unrelated changes were not touched; tests used isolated APPDATA. No commits, pushes, deployment, tactical implementation or native Computer Use.

No implemented interior maps or north/south paired maps exist to exercise end-to-end. Arrival logic accepts arbitrary inward vectors, and vertical placement is tested; new doorway links still require authored entrance metadata. Safe placement may return fewer than six points if terrain is genuinely too constrained; future party deployment must handle that explicitly. Production dialogue remains the original simple conversations; branching is verified with test-only choices. Physical phone/tablet devices were not tested. Existing camera behavior may reveal background beyond short maps in tall viewports; no camera/map redesign was attempted.
