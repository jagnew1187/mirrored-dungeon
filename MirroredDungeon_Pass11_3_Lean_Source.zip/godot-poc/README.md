Pass 11 (2026-11-01): six-position party/reserve architecture, individual sheets and equipment, shared inventory, functional talent graphs and derived class evolution. Schema 5 migration; 1,205 automated checks pass. See [Pass 11 report](PASS11_REPORT.md) and [save migration](PASS11_SAVE_MIGRATION.md). Original art is reused unchanged; no companions are automatically recruited.

Pass 10.2 (2026-11-01): ten functional equipment slots, safe schema-4 migration and visible camp recovery. 1,060 automated checks pass. See [Pass 10.2 report](PASS102_REPORT.md) for diagnosis, launch instructions, evidence and limitations. Existing art is unchanged.

# Mirrored Dungeon — Godot Pass 10.1

Pass 10.1 corrects legacy boots to Feet with atomic migration, adds the HUD Character button and C/Escape controls, and provides compact illustrated item popups with real numerical properties and colored derived comparisons. All 96 gear definitions and 15 slots remain functional. See [PASS10_1_REPORT.md](PASS10_1_REPORT.md) for 896 passing assertions, migration details, screenshots, preservation and limitations. Prior reports remain historical. Gear does not change hero sprites; no Computer Use was performed.

## Open on Windows

1. Extract **MirroredDungeon_Godot_Pass10_1_20261101.zip** completely.
2. In Godot 4.7.2 Standard Project Manager choose **Import**, then `godot-poc/project.godot` and **Import & Edit**.
3. Allow asset import, then press **F5**. Choose **New Campaign**, optionally enter a name, and select Knight, Mage or Rogue. **Continue** opens an existing separate hero slot.

Uses the Compatibility renderer. No C#, plugins, Python, Node, JavaScript repository or network service is required to play. Earlier Godot versions are untested. The original POC ZIP is an older build and is deliberately preserved.

## Play

- WASD/arrows move. Left click walks, approaches NPCs, collects loot or approaches and attacks a selected enemy. Manual movement cancels automatic approach.
- Space/right mouse/Attack button attacks; hold to repeat. E interacts or collects nearby loot.
- C or the HUD Character button toggles the sheet. Escape dismisses an item popup first, then closes the sheet. I also opens equipment/inventory. J opens the quest journal. Esc/Menu pauses. Inventory/dialogue pauses combat and hides combat controls.
- Touch controls support dragging the lower-left movement area and tapping targets/Attack; physical mobile-device testing is outstanding.
- Visit Mara at Vigil, take the eastern exit, follow Old Mill Road northeast, defeat both marked mill guards, explicitly collect the flour, then take the southeast exit to Bannerfall and speak to Anja at her bakery. Return to Vigil to bank or trade your loot.
- Click Vigil's protected chest for stash operations; the supply table opens trading. Nearby service tabs permit backpack/stash/supplies access. Select an item to inspect, compare, equip, use, deposit, withdraw or sell. Purchases and sales require an in-game confirmation. Rest restores health.

Backpack: 16 slots. Stash: 40 slots. Tonics stack to five and restore 60 health. All 15 equipment slots affect calculated combat stats. Right-click carried gear for Quick Equip; the character sheet exposes two renameable loadouts, sorting, filters, favorites and sale locks. Item drops stay on the ground if the backpack is full. Coins are awarded on enemy defeat. Level cap 60; the short quest is designed to reach level 2, not provide a full leveling campaign.

## Saves and recovery

Each new hero gets a new Godot-only slot. Automatic saves follow progression, inventory operations and area changes. Continue returns to the most recent safe camp/town checkpoint. Death pauses and offers safe recovery or title; XP, items, stash, coins, completed encounters and quest claims are retained. Unfinished enemies reset; completed authored guards do not respawn. Wounds/position are not persisted: recovery and Continue heal at the safe checkpoint.

Saves live in Godot's `user://campaigns` directory, normally `%APPDATA%/Godot/app_userdata/Mirrored Dungeon — Godot POC/campaigns`. Primary JSON records use validated temporary writes and last-valid `.bak` copies. Version 1/2 records migrate to version 3 while preserving old item IDs and worn equipment. Before replacement, valid legacy originals are retained as `.json.pre-v3.bak`. Legacy boots in trinket positions migrate atomically to Feet or available backpack space, with originals retained in `.json.pre-feet.bak`. If occupied Feet and a full backpack conflict, loading stops without backup substitution; free space in the previous build first. Unknown item references or future schemas block replacement rather than being silently discarded. Invalid files are retained; a valid backup can recover a broken primary. Browser/JavaScript saves are never read or migrated. Copy this whole save directory to back it up. Visible save errors mean progress is still in memory and durability was not guaranteed.

## Documentation and testing

See **PASS10_REPORT.md** for current systems, balance, evidence and limitations. See **PASS05_REPORT.md** for historical systems. **PASS04_REPORT.md** records the preceding checkpoint. **CHANGELOG.md** records changes; **REPOSITORY_STATUS.txt** records the exact working-tree status at delivery.

Current suites: `tests/pass05.gd`, `tests/pass02_contracts.gd`, `tests/pass06.gd`, `tests/pass06_campaign.gd`, `tests/pass07.gd`, `tests/pass08.gd`, `tests/pass09.gd`, and `tests/pass10.gd`. See PASS10_VISUAL_REVIEW.md and tests/pass10-captures for current engine-generated visual evidence. Run with Godot `--headless --path godot-poc --script res://tests/pass05.gd --fixed-fps 60` using an isolated APPDATA directory. Engine fixtures are not physical gameplay tests. Desktop JPEG evidence is under `tests/desktop-pass04` and `tests/desktop-pass05`. Historical playthrough tests and one-shot integration scripts have `.txt` suffixes; do not rerun those against this build. Older Pass 01/02 evidence is historical, not current acceptance.

